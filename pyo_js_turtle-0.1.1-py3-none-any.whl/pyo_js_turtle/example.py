# __all__ = ('add_one', 'add_ten')

#def add_one(x: int)-> int:
#    return x+1


#def add_ten(x: int)-> int:
#    return x+10
